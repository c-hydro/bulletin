"""
Meteo bulletin components.
"""
